# Databricks notebook source
raw_folder_path = "dbfs:/mnt/formula1dlkaran/raw"
processed_folder_path = "dbfs:/mnt/formula1dlkaran/processed"
presentation_folder_path = "dbfs:/mnt/formula1dlkaran/presentation"