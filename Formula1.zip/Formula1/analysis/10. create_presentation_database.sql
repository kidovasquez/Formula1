-- Databricks notebook source
create database if not exists f1_presentation
location "dbfs:/mnt/formula1dlkaran/presentation"

-- COMMAND ----------

desc database f1_presentation;